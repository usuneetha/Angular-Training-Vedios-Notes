import {Component} from '@angular/core'

@Component({
    selector:'event-list',
 //   templateUrl:'./eventlist.html',
    template:`
            <div>
                <h1>Upcoming Angular Events</h1>
                <hr/>
                <event-thumbnail [event]="event"></event-thumbnail>
                
                <button (click)="display()">Click Me</button>
                <br/>
                Change City<input type="text" [(ngModel)]='city' />
                <br/>
                <span>{{city}}</span>
            </div>
    `,
     styles:[`
        h1{color:red}
    `]
})
export class EventListComponent{

    city='Mumbai'
    event={
        id:1,
        name:'Angular Connect',
        date:'01/01/2020',
        time:'8:00 am',
        price:456,
        location:{
            address:'201',
            city:'Pune',
            country:'India'
        }
    }

    display(){
        console.log("Inside display...")
    }
}
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {EventListComponent} from './events/eventlist.component'
import {EventThumbnailComponent} from './events/event.thumbnail.component'
import {FormsModule} from '@angular/forms'

@NgModule({
  declarations: [
    AppComponent,EventListComponent,EventThumbnailComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

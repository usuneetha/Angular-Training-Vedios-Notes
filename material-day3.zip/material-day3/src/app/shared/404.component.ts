import {Component} from '@angular/core'

@Component({
    template:`
        <div>
            <h1>Sorry Page not found</h1>
        </div>
    `
})
export class Error404Component{

}
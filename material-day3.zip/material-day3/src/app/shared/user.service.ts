import {Injectable} from '@angular/core'
import {IUser} from '../user/user.model'

@Injectable()
export class UserService{

    currentUser:IUser

    validateUser(uName:string,password:string){
        //talk to restful service
        this.currentUser={
            id:1,
            userName:uName,
            firstName:'Aakash',
            lastName:'Agarwal'
        }
    }

}
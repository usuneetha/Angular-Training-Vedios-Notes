import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import {RouterModule} from '@angular/router'
import { AppComponent } from './app.component';

import {EventListComponent,EventThumbnailComponent,EventDetComponent,CreateEventComponent}
from './events/index'
import {EventService,Error404Component,EventRouteActivatorService} 
from './shared/index'

import {NavBarComponent} from './nav/navbar.component'
import {appRoutes} from './route'

@NgModule({
  declarations: [
    AppComponent,EventListComponent,EventThumbnailComponent,NavBarComponent,
    EventDetComponent,CreateEventComponent,Error404Component
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [EventService,EventRouteActivatorService],
  bootstrap: [AppComponent]
})
export class AppModule { }

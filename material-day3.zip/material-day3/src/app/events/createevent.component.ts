import {Component} from '@angular/core'
import {Router} from '@angular/router'

@Component({
    template:`
        <h1>New Event</h1>
        <hr/>
        <div>
            <h3>[New Event Form goes here]</h3>
            <br/>
            <button>Save</button>
            <button (click)="cancelMe()">Cancel</button>
        </div>
    
    `
})
export class CreateEventComponent{

        constructor(private router:Router){

        }
        cancelMe(){
           //i may check for some condition
           //based on the condition you may have decide to 
           //which route path you want to send the user
           this.router.navigate(['/events'])
        }
}
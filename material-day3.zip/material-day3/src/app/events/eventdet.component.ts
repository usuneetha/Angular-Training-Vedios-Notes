import {Component} from '@angular/core'
import {EventService,IEvent} from '../shared/index'
import {ActivatedRoute} from '@angular/router'

@Component({
    templateUrl:'./eventdetails.html',
    styles:[`
        .event-image{height:100px}
    `]
}) 
export class EventDetComponent{
    event:IEvent

    constructor(private es:EventService,private actRoute:ActivatedRoute){
        this.event=es.getEvent(+this.actRoute.snapshot.params['id'])
    }
}
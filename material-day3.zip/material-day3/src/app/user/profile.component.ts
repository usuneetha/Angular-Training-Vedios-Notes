import {Component} from '@angular/core'

@Component({
    template:`
        <div>
            <h1>Profile Form to be created</h1>
        </div>
    
    `
})
export class ProfileComponent{

}
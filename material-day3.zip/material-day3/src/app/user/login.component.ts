import {Component} from '@angular/core'

@Component({
    templateUrl:'./login.html'
})
export class LoginComponent{

    login(formValues){
        //talk to userservice
        console.log(formValues)
    }
}
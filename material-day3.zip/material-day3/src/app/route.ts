import {Routes} from '@angular/router'
import {EventListComponent} from './events/eventlist.component'
import {EventDetComponent} from './events/eventdet.component'
import {CreateEventComponent} from './events/createevent.component'
import {Error404Component} from './shared/404.component'
import {EventRouteActivatorService} from './shared/eventrouteact.service'

export const appRoutes:Routes=[
    {path:'events/new',component:CreateEventComponent},
    {path:'events',component:EventListComponent},
    {path:'events/:id',component:EventDetComponent,canActivate:[EventRouteActivatorService]},
    {path:'404',component:Error404Component},
    {path:'',redirectTo:'events',pathMatch:'full'},
    {path:'user',loadChildren:'src/app/user/user.module#UserModule'}
]
import {Injectable} from '@angular/core'
import {Observable} from 'rxjs'
import {Item} from './item.model'
import {HttpClient} from '@angular/common/http'


@Injectable()
export class TechService{
    url="https://www.techiediaries.com/api/data.json"

    constructor(private httpClient:HttpClient){

    }

    fetchData():Observable<Item[]>{
        return <Observable<Item[]>>this.httpClient.get(this.url)
    }


}
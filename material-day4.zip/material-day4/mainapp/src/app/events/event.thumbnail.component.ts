import {Component,Input,Output,EventEmitter} from '@angular/core'
import {IEvent} from '../shared/event.model'

@Component({
    selector:'event-thumbnail',
    template:`
         <div [routerLink]="['/events',event.id]" class="well hoverwell thumbnail">
            <h2>{{event?.name|uppercase}}</h2>   
            <div>Date: {{event?.date|date:'y/M/d'}}</div>
            <div [ngStyle]="pickupstyle()" [ngSwitch]="event?.time">
                Time: {{event?.time}} 
                <span *ngSwitchCase="'10:00 am'">[Late Start]</span>
                <span *ngSwitchCase="'9:00 am'">[Regular Start]</span>
                <span *ngSwitchDefault>[Early Start]</span>
            </div>
            <div>Price: {{event?.price|currency:'EUR'}} </div>
            <div *ngIf="event?.location">
                <span>Location:{{event?.location?.address}}</span>
                <span>{{event?.location?.city}},{{event?.location?.country}}</span>
            </div> 
            <div *ngIf="event?.onlineUrl">OnlineUrl: {{event.onlineUrl}}</div>
            <div>{{3.1415992|number:'3.1-2'}}</div>
            <div>{{[1,2,3,4,5,6]|slice:2:4}}</div>
        </div>
    
    `,
    styles:[`
            .thumbnail{min-height:200px}
            .myredclass{color:red}
            .mygreenclass{color:green}
    `]
})
export class EventThumbnailComponent{
    @Input() event:IEvent
   
    pickupstyle(){
        if(this.event.time==='10:00 am'){
            return {color:'red','font-weight':'bold'}
        }else{
            return {color:'green'}
        }
    }
}


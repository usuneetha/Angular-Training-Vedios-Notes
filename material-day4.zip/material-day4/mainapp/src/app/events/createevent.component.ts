import {Component} from '@angular/core'
import {Router} from '@angular/router'
import {EventService} from '../shared/event.service'

@Component({
   templateUrl:'./createevent.html'
})
export class CreateEventComponent{

        constructor(private router:Router,private es:EventService){

        }
        cancelMe(){
           //i may check for some condition
           //based on the condition you may have decide to 
           //which route path you want to send the user
        
           this.router.navigate(['/events'])
        }

        saveEvent(formValues){
            //take all the data and add it to events array
            this.es.addNewEvent(formValues)
            this.router.navigate(['/events'])
            //console.log(formValues)
        }
}
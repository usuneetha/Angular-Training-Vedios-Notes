import {Component} from '@angular/core'
import {EventService,IEvent} from '../shared/index'

@Component({
    selector:'event-list',
 //   templateUrl:'./eventlist.html',
    template:`
            <div>
                <h1>Upcoming Angular Events</h1>
                <hr/>

                <div *ngFor="let event of events" class="col-md-5">
                    <event-thumbnail [event]=event></event-thumbnail>
                </div>
            </div>
    `
    
})
export class EventListComponent{

        events:IEvent[]

        constructor(private es:EventService){
            this.events=es.getEvents()
        }    

   
}
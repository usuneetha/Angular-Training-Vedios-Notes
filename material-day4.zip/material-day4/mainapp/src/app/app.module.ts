import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import {RouterModule} from '@angular/router'
import { AppComponent } from './app.component';

import {EventListComponent,EventThumbnailComponent,EventDetComponent,
  CreateEventComponent,SessionListComponent} from './events/index'
  
import {EventService,Error404Component,EventRouteActivatorService,UserService,DurationPipe} 
from './shared/index'

import {AsyncPipe1Component} from './asyncpipedemo/asyncpipe1.component'

import {NavBarComponent} from './nav/navbar.component'
import {appRoutes} from './route'

@NgModule({
  declarations: [
    AppComponent,EventListComponent,EventThumbnailComponent,NavBarComponent,
    EventDetComponent,CreateEventComponent,Error404Component,SessionListComponent,
    DurationPipe,AsyncPipe1Component
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [EventService,EventRouteActivatorService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }

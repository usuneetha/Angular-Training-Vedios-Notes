import {Injectable} from '@angular/core'
import {IUser} from '../user/user.model'

@Injectable()
export class UserService{

    currentUser:IUser

    validateUser(uName:string,password:string){
        //talk to restful service
        this.currentUser={
            id:1,
            userName:uName,
            firstName:'Aakash',
            lastName:'Agarwal'
        }
    }

    isAuthenticated(){
        return !!this.currentUser
    }

    updateUser(fName:string,lName:string){
        //assign the new values of first name and llast name to currentuser var
        this.currentUser.firstName=fName
        this.currentUser.lastName=lName
        //give that currentuser var to restful service
    }

}
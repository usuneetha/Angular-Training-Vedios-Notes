import {Component} from '@angular/core'
import {UserService} from '../shared/user.service'
import {Router} from '@angular/router'

@Component({
    templateUrl:'./login.html',
    styles:[`
        em{color:red;float:right}
    
    `]
})
export class LoginComponent{

    constructor(private us:UserService,private router:Router){

    }
    login(formValues){
        //talk to userservice
        this.us.validateUser(formValues.userName,formValues.password)
       //after validating we should redirect the user to some route path
       this.router.navigate(['events'])
    }
}
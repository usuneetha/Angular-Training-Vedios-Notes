import {Component} from '@angular/core'
import {FormGroup,FormControl,Validators} from '@angular/forms'
import {UserService} from '../shared/user.service'
import {Router} from '@angular/router'

@Component({
   templateUrl:'./profile.html',
   styles:[`
        em{color:red;float:right}
   `]
})
export class ProfileComponent{
    profileForm:FormGroup
    firstName: FormControl
    lastName: FormControl

    constructor(private us:UserService,private router:Router){

    }

    ngOnInit(){
        this.firstName=new FormControl(this.us.currentUser.firstName,
            [Validators.required,Validators.pattern('[a-zA-Z].*')])
        this.lastName=new FormControl(this.us.currentUser.lastName,Validators.required)
        this.profileForm=new FormGroup({
            firstName:this.firstName,
            lastName:this.lastName
        })
    }

    save(formValues){
        this.us.updateUser(formValues.firstName,formValues.lastName)
        this.router.navigate(['events'])
    }

    //method return true if it is valid and untouched
    validateFirstName(){
        return this.firstName.valid || this.firstName.untouched
    }

    //method return true if it is valid and untouched
    validateLastName(){
        return this.lastName.valid || this.lastName.untouched
    }
}